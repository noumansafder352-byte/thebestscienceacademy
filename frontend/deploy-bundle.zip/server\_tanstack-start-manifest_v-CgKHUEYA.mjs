//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CgKHUEYA.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/august_science_academy_project/Science-Academy/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/admin",
			"/become-a-tutor",
			"/contact",
			"/privacy",
			"/programs",
			"/sitemap.xml",
			"/subjects",
			"/terms",
			"/tutors/$slug",
			"/tutors/"
		],
		preloads: [
			"/assets/index-pS089hB4.js",
			"/assets/jsx-runtime-BKllkxft.js",
			"/assets/link-x8UZ2-UV.js",
			"/assets/createMiddleware-Bi-ToyvZ.js",
			"/assets/invariant-DEEwAagU.js",
			"/assets/useMatch-BsdQq1HX.js",
			"/assets/useRouter-DQzVw-2q.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-pS089hB4.js"
		} }]
	},
	"/": {
		filePath: "D:/august_science_academy_project/Science-Academy/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-5kSPVKTM.js",
			"/assets/tutor-api.functions-BD5oeCGk.js",
			"/assets/useQuery-D3F44fvX.js",
			"/assets/createLucideIcon-BXvMJD5C.js",
			"/assets/arrow-right-Z0TkZNJ-.js",
			"/assets/sigma-BIy93miL.js",
			"/assets/book-open-UkXeFNbm.js",
			"/assets/briefcase-CTtcxH_h.js",
			"/assets/calendar-clock-CXjDc1Jv.js",
			"/assets/chart-line-BoOGV_Gq.js",
			"/assets/circle-check-D18l1LKx.js",
			"/assets/layout-C9m8vH1T.js",
			"/assets/graduation-cap-J7NItMB1.js",
			"/assets/languages-01YJk1tV.js",
			"/assets/message-square-gEmtwCk-.js",
			"/assets/shield-check-DkvtW4EV.js",
			"/assets/sparkles-CCVl1gRM.js",
			"/assets/star-DGg3hN1W.js",
			"/assets/users-CJ1EluYZ.js",
			"/assets/video-qRzbT2pd.js",
			"/assets/site-data-B6sOkp_r.js",
			"/assets/tutor-card-C_lYGChF.js"
		]
	},
	"/about": {
		filePath: "D:/august_science_academy_project/Science-Academy/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-BgqBvrcI.js",
			"/assets/createLucideIcon-BXvMJD5C.js",
			"/assets/arrow-right-Z0TkZNJ-.js",
			"/assets/book-open-UkXeFNbm.js",
			"/assets/chart-line-BoOGV_Gq.js",
			"/assets/layout-C9m8vH1T.js",
			"/assets/graduation-cap-J7NItMB1.js",
			"/assets/sparkles-CCVl1gRM.js",
			"/assets/page-header-DFErhD4s.js"
		]
	},
	"/admin": {
		filePath: "D:/august_science_academy_project/Science-Academy/src/routes/admin.tsx",
		children: [
			"/admin/applications",
			"/admin/login",
			"/admin/messages",
			"/admin/settings",
			"/admin/students",
			"/admin/tutors",
			"/admin/"
		],
		preloads: [
			"/assets/admin-Sf_ABibK.js",
			"/assets/tutor-api.functions-BD5oeCGk.js",
			"/assets/useRouterState-LmZsIU9W.js",
			"/assets/useQuery-D3F44fvX.js",
			"/assets/createLucideIcon-BXvMJD5C.js",
			"/assets/chevron-down-Bc7qjiwm.js",
			"/assets/file-text-Bcu5lp4X.js",
			"/assets/graduation-cap-J7NItMB1.js",
			"/assets/mail-C_YLukyU.js",
			"/assets/menu-BomqNm_g.js",
			"/assets/search-Cc-yeZA1.js",
			"/assets/settings-CprxVQ9_.js",
			"/assets/users-CJ1EluYZ.js",
			"/assets/x-Br4Dstqh.js",
			"/assets/use-auth-BP5iAf_9.js"
		]
	},
	"/become-a-tutor": {
		filePath: "D:/august_science_academy_project/Science-Academy/src/routes/become-a-tutor.tsx",
		children: void 0,
		css: ["/assets/phone-field-Rkh5BCSq.css"],
		preloads: [
			"/assets/become-a-tutor-C_aSiNSp.js",
			"/assets/tutor-api.functions-BD5oeCGk.js",
			"/assets/createLucideIcon-BXvMJD5C.js",
			"/assets/arrow-right-Z0TkZNJ-.js",
			"/assets/award-B6uR1ju1.js",
			"/assets/briefcase-CTtcxH_h.js",
			"/assets/circle-check-D18l1LKx.js",
			"/assets/clock-DEEh0oyh.js",
			"/assets/layout-C9m8vH1T.js",
			"/assets/file-text-Bcu5lp4X.js",
			"/assets/graduation-cap-J7NItMB1.js",
			"/assets/mail-C_YLukyU.js",
			"/assets/phone-DDGd0qcY.js",
			"/assets/shield-check-DkvtW4EV.js",
			"/assets/sparkles-CCVl1gRM.js",
			"/assets/upload-yE3nZfWN.js",
			"/assets/user-CkdSJxNd.js",
			"/assets/users-CJ1EluYZ.js",
			"/assets/x-Br4Dstqh.js",
			"/assets/page-header-DFErhD4s.js",
			"/assets/phone-field-N7DnQ4eI.js"
		]
	},
	"/contact": {
		filePath: "D:/august_science_academy_project/Science-Academy/src/routes/contact.tsx",
		children: void 0,
		css: ["/assets/phone-field-Rkh5BCSq.css"],
		preloads: [
			"/assets/contact-CI3MkjF7.js",
			"/assets/tutor-api.functions-BD5oeCGk.js",
			"/assets/arrow-right-Z0TkZNJ-.js",
			"/assets/circle-check-D18l1LKx.js",
			"/assets/layout-C9m8vH1T.js",
			"/assets/mail-C_YLukyU.js",
			"/assets/map-pin-CL9IWESl.js",
			"/assets/message-circle-Cq5iVOcg.js",
			"/assets/phone-DDGd0qcY.js",
			"/assets/page-header-DFErhD4s.js",
			"/assets/phone-field-N7DnQ4eI.js"
		]
	},
	"/privacy": {
		filePath: "D:/august_science_academy_project/Science-Academy/src/routes/privacy.tsx",
		children: void 0,
		preloads: [
			"/assets/privacy-onKQrDwd.js",
			"/assets/layout-C9m8vH1T.js",
			"/assets/page-header-DFErhD4s.js"
		]
	},
	"/programs": {
		filePath: "D:/august_science_academy_project/Science-Academy/src/routes/programs.tsx",
		children: void 0,
		preloads: [
			"/assets/programs-BhfJc05u.js",
			"/assets/arrow-right-Z0TkZNJ-.js",
			"/assets/chevron-down-Bc7qjiwm.js",
			"/assets/chevron-up-B4FDPRzi.js",
			"/assets/circle-check-D18l1LKx.js",
			"/assets/layout-C9m8vH1T.js",
			"/assets/page-header-DFErhD4s.js",
			"/assets/site-data-B6sOkp_r.js"
		]
	},
	"/subjects": {
		filePath: "D:/august_science_academy_project/Science-Academy/src/routes/subjects.tsx",
		children: void 0,
		preloads: [
			"/assets/subjects-wWMIlahs.js",
			"/assets/arrow-right-Z0TkZNJ-.js",
			"/assets/sigma-BIy93miL.js",
			"/assets/book-open-UkXeFNbm.js",
			"/assets/briefcase-CTtcxH_h.js",
			"/assets/chart-line-BoOGV_Gq.js",
			"/assets/layout-C9m8vH1T.js",
			"/assets/languages-01YJk1tV.js",
			"/assets/message-square-gEmtwCk-.js",
			"/assets/users-CJ1EluYZ.js",
			"/assets/page-header-DFErhD4s.js",
			"/assets/site-data-B6sOkp_r.js"
		]
	},
	"/terms": {
		filePath: "D:/august_science_academy_project/Science-Academy/src/routes/terms.tsx",
		children: void 0,
		preloads: [
			"/assets/terms-Db3MXBMB.js",
			"/assets/layout-C9m8vH1T.js",
			"/assets/page-header-DFErhD4s.js"
		]
	},
	"/admin/applications": {
		filePath: "D:/august_science_academy_project/Science-Academy/src/routes/admin.applications.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.applications-BFf2FFo4.js",
			"/assets/useMutation-DSV3PR--.js",
			"/assets/circle-check-D18l1LKx.js",
			"/assets/clock-DEEh0oyh.js",
			"/assets/inbox-CcEz9Dk7.js",
			"/assets/message-circle-Cq5iVOcg.js",
			"/assets/phone-DDGd0qcY.js",
			"/assets/triangle-alert-BZIDuJIl.js",
			"/assets/admin-ui-K3zxwhBu.js"
		]
	},
	"/admin/login": {
		filePath: "D:/august_science_academy_project/Science-Academy/src/routes/admin.login.tsx",
		children: void 0,
		preloads: ["/assets/admin.login-cVD4E85i.js", "/assets/shield-check-DkvtW4EV.js"]
	},
	"/admin/messages": {
		filePath: "D:/august_science_academy_project/Science-Academy/src/routes/admin.messages.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.messages-DchNjTFP.js",
			"/assets/useMutation-DSV3PR--.js",
			"/assets/inbox-CcEz9Dk7.js",
			"/assets/phone-DDGd0qcY.js",
			"/assets/triangle-alert-BZIDuJIl.js",
			"/assets/admin-ui-K3zxwhBu.js"
		]
	},
	"/admin/settings": {
		filePath: "D:/august_science_academy_project/Science-Academy/src/routes/admin.settings.tsx",
		children: void 0,
		preloads: ["/assets/admin.settings-BIjsGvzO.js", "/assets/admin-ui-K3zxwhBu.js"]
	},
	"/admin/students": {
		filePath: "D:/august_science_academy_project/Science-Academy/src/routes/admin.students.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.students-CXSmWEI7.js",
			"/assets/calendar-clock-CXjDc1Jv.js",
			"/assets/inbox-CcEz9Dk7.js",
			"/assets/admin-ui-K3zxwhBu.js"
		]
	},
	"/admin/tutors": {
		filePath: "D:/august_science_academy_project/Science-Academy/src/routes/admin.tutors.tsx",
		children: ["/admin/tutors/$id/edit"],
		preloads: [
			"/assets/admin.tutors-CEYLj5ko.js",
			"/assets/useMutation-DSV3PR--.js",
			"/assets/inbox-CcEz9Dk7.js",
			"/assets/star-DGg3hN1W.js",
			"/assets/triangle-alert-BZIDuJIl.js",
			"/assets/admin-ui-K3zxwhBu.js"
		]
	},
	"/tutors/$slug": {
		filePath: "D:/august_science_academy_project/Science-Academy/src/routes/tutors.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/tutors._slug-Bc8AiJ0m.js",
			"/assets/layout-C9m8vH1T.js",
			"/assets/tutors._slug-CNw996L2.js",
			"/assets/tutor-api.functions-BD5oeCGk.js",
			"/assets/useBaseQuery-Dv7quEac.js",
			"/assets/createLucideIcon-BXvMJD5C.js",
			"/assets/arrow-right-Z0TkZNJ-.js",
			"/assets/award-B6uR1ju1.js",
			"/assets/book-open-UkXeFNbm.js",
			"/assets/chevron-down-Bc7qjiwm.js",
			"/assets/chevron-up-B4FDPRzi.js",
			"/assets/circle-check-D18l1LKx.js",
			"/assets/clock-DEEh0oyh.js",
			"/assets/graduation-cap-J7NItMB1.js",
			"/assets/languages-01YJk1tV.js",
			"/assets/map-pin-CL9IWESl.js",
			"/assets/message-square-gEmtwCk-.js",
			"/assets/shield-check-DkvtW4EV.js",
			"/assets/sparkles-CCVl1gRM.js",
			"/assets/star-DGg3hN1W.js",
			"/assets/user-CkdSJxNd.js",
			"/assets/video-qRzbT2pd.js",
			"/assets/tutor-badges-H4m22SCV.js",
			"/assets/tutors._slug-JJFe_oh0.js"
		]
	},
	"/admin/": {
		filePath: "D:/august_science_academy_project/Science-Academy/src/routes/admin.index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.index-CUMlk6x6.js",
			"/assets/arrow-right-Z0TkZNJ-.js",
			"/assets/award-B6uR1ju1.js",
			"/assets/inbox-CcEz9Dk7.js",
			"/assets/message-square-gEmtwCk-.js",
			"/assets/sparkles-CCVl1gRM.js",
			"/assets/star-DGg3hN1W.js"
		]
	},
	"/tutors/": {
		filePath: "D:/august_science_academy_project/Science-Academy/src/routes/tutors.index.tsx",
		children: void 0,
		preloads: [
			"/assets/tutors.index-Bx_V_Hvj.js",
			"/assets/tutor-api.functions-BD5oeCGk.js",
			"/assets/useQuery-D3F44fvX.js",
			"/assets/createLucideIcon-BXvMJD5C.js",
			"/assets/layout-C9m8vH1T.js",
			"/assets/search-Cc-yeZA1.js",
			"/assets/shield-check-DkvtW4EV.js",
			"/assets/sparkles-CCVl1gRM.js",
			"/assets/page-header-DFErhD4s.js",
			"/assets/tutor-card-C_lYGChF.js"
		]
	},
	"/admin/tutors/$id/edit": {
		filePath: "D:/august_science_academy_project/Science-Academy/src/routes/admin.tutors.$id.edit.tsx",
		children: void 0,
		preloads: ["/assets/admin.tutors._id.edit-BSai30Yo.js", "/assets/upload-yE3nZfWN.js"]
	}
} });
//#endregion
export { tsrStartManifest };
