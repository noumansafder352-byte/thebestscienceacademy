/*
 * cPanel "Setup Node.js App" (Passenger) startup file.
 *
 * Passenger loads this file with CommonJS `require`, so it MUST stay a .cjs
 * file. It dynamically imports the ESM Nitro server produced by the build
 * (`.output/server/index.mjs`), which starts an HTTP listener that Passenger
 * routes traffic to automatically — do not set PORT yourself.
 *
 * Place this file in the SAME folder as the uploaded `.output` directory
 * (your Application Root), then set it as the "Application startup file".
 */
import("./.output/server/index.mjs").catch((err) => {
  console.error("[startup] Failed to boot the server:", err);
  process.exit(1);
});
