import { s as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { S as Search } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-ui-EM48c1k2.js
var import_jsx_runtime = require_jsx_runtime();
/** Consistent page header used across every admin sub-page. */
function AdminPageHeader({ icon: Icon, title, subtitle, accent = "bg-primary-soft text-primary", children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 items-center gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl shadow-soft ${accent}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-bold tracking-tight text-ink sm:text-2xl",
					children: title
				}), subtitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-0.5 text-sm text-muted-foreground",
					children: subtitle
				})]
			})]
		}), children && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap items-center gap-2",
			children
		})]
	});
}
/** Compact KPI tile with a colored icon chip. */
function StatTile({ icon: Icon, label, value, accent = "bg-primary-soft text-primary", hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card-surface p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${accent}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 font-display text-2xl font-bold tabular-nums text-ink",
				children: value
			}),
			hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-0.5 text-xs text-muted-foreground/70",
				children: hint
			})
		]
	});
}
/** Segmented pill control for status filters. */
function FilterTabs({ value, onChange, options }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "inline-flex items-center gap-1 rounded-full border border-border bg-surface p-1",
		children: options.map((o) => {
			const active = value === o.key;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => onChange(o.key),
				className: `inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-xs font-semibold capitalize transition-colors ${active ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-ink"}`,
				children: [o.label, o.count != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: active ? "text-primary-foreground/75" : "text-muted-foreground/60",
					children: o.count
				})]
			}, o.key);
		})
	});
}
/** Rounded search field matching the admin shell. */
function SearchInput({ value, onChange, placeholder, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `relative ${className}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value,
			onChange: (e) => onChange(e.target.value),
			placeholder,
			className: "h-10 w-full rounded-full border border-border bg-surface-2 pl-9 pr-4 text-sm outline-none transition-colors focus:border-primary focus:bg-surface"
		})]
	});
}
/** Friendly empty state — drop inside a table cell (with colSpan) or a card. */
function EmptyState({ icon: Icon, title, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center justify-center px-4 py-14 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-12 w-12 items-center justify-center rounded-2xl bg-surface-2 text-muted-foreground/50",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-6 w-6" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm font-medium text-ink",
				children: title
			}),
			hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted-foreground",
				children: hint
			})
		]
	});
}
/** Circular initials avatar. */
function AdminAvatar({ name, className = "h-9 w-9 text-xs" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `flex shrink-0 items-center justify-center rounded-full bg-primary-soft font-bold text-primary ${className}`,
		children: adminInitials(name)
	});
}
function adminInitials(name) {
	if (!name) return "?";
	return name.trim().split(/\s+/).map((p) => p[0]).slice(0, 2).join("").toUpperCase();
}
/** Shared table shell classes so every admin table matches. */
var tableHeadRow = "text-left text-[11px] uppercase tracking-wider text-muted-foreground border-b border-border";
var tableRow = "border-b border-border/70 transition-colors hover:bg-surface-2/60 last:border-0";
//#endregion
export { SearchInput as a, tableRow as c, FilterTabs as i, AdminPageHeader as n, StatTile as o, EmptyState as r, tableHeadRow as s, AdminAvatar as t };
