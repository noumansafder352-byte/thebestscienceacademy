import { r as __toESM } from "../_runtime.mjs";
import { c as require_react, i as useQuery, s as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { Nt as ArrowUpRight, P as MessageSquare, Pt as ArrowRight, Q as Inbox, _ as Sparkles, a as Users, at as FileText, c as UserPlus, g as Star, jt as Award, p as TrendingUp, tt as GraduationCap, z as Mail } from "../_libs/lucide-react.mjs";
import { D as useServerFn, d as adminListMessages, f as adminListTutors, l as adminListApplications, v as adminStatsSummary } from "./tutor-api.functions-BgQ4s39o.mjs";
import { t as useAuth } from "./use-auth-B7VfCL3m.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.index-DgW6ATKr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminHome() {
	const { user } = useAuth();
	const statsFn = useServerFn(adminStatsSummary);
	const appsFn = useServerFn(adminListApplications);
	const tutorsFn = useServerFn(adminListTutors);
	const msgsFn = useServerFn(adminListMessages);
	const stats = useQuery({
		queryKey: ["admin-stats"],
		queryFn: () => statsFn()
	});
	const apps = useQuery({
		queryKey: ["admin-applications"],
		queryFn: () => appsFn()
	});
	const tutors = useQuery({
		queryKey: ["admin-tutors"],
		queryFn: () => tutorsFn()
	});
	const msgs = useQuery({
		queryKey: ["admin-messages"],
		queryFn: () => msgsFn()
	});
	const [now, setNow] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setNow(/* @__PURE__ */ new Date());
		const t = setInterval(() => setNow(/* @__PURE__ */ new Date()), 6e4);
		return () => clearInterval(t);
	}, []);
	const hour = now?.getHours() ?? -1;
	const greeting = hour < 0 ? "Welcome back" : hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
	const dateStr = now ? now.toLocaleDateString(void 0, {
		weekday: "long",
		day: "numeric",
		month: "long",
		year: "numeric"
	}) : "";
	const adminName = capitalize((user?.email ?? "").split("@")[0] || "Admin");
	const a = stats.data?.applications;
	const pending = a?.pending;
	const statusLine = pending == null ? "Loading your academy overview…" : pending > 0 ? `${pending} application${pending === 1 ? "" : "s"} awaiting your review.` : "You're all caught up — no applications in the queue.";
	const statCards = [
		{
			label: "Pending applications",
			value: a?.pending,
			hint: "Awaiting review",
			icon: UserPlus,
			to: "/admin/applications",
			tile: "bg-amber-100 text-amber-700"
		},
		{
			label: "Active tutors",
			value: stats.data?.tutors,
			hint: "Published on site",
			icon: GraduationCap,
			to: "/admin/tutors",
			tile: "bg-primary-soft text-primary"
		},
		{
			label: "Trial bookings",
			value: stats.data?.bookings,
			hint: "Requested lessons",
			icon: Users,
			to: "/admin/students",
			tile: "bg-emerald-100 text-emerald-700"
		},
		{
			label: "Contact messages",
			value: stats.data?.messages,
			hint: "In your inbox",
			icon: Mail,
			to: "/admin/messages",
			tile: "bg-sky-100 text-sky-700"
		}
	];
	const pendingApps = (apps.data ?? []).filter((x) => x.status === "pending");
	const topTutors = (tutors.data ?? []).filter((t) => t.is_active && !t.deleted_at).sort((x, y) => (y.rating ?? 0) - (x.rating ?? 0)).slice(0, 5);
	const latestMessages = (msgs.data ?? []).slice(0, 4);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative overflow-hidden rounded-3xl bg-ink text-white shadow-glow",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "blob h-64 w-64 -top-24 -left-10",
						style: { background: "var(--color-primary-glow)" }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "blob h-72 w-72 -bottom-28 -right-8",
						style: { background: "var(--color-gold-glow)" }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "noise" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 flex flex-col gap-6 p-6 sm:p-8 lg:flex-row lg:items-end lg:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-white/80",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3 w-3" }), " Dashboard"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
									className: "mt-4 text-2xl font-bold tracking-tight text-white sm:text-3xl",
									children: [
										greeting,
										", ",
										adminName
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-sm text-white/70",
									children: [
										dateStr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-white/90",
											children: dateStr
										}),
										dateStr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mx-2 text-white/30",
											children: "·"
										}),
										statusLine
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/admin/applications",
								className: "btn-gold",
								children: ["Review applications ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/admin/tutors",
								className: "inline-flex items-center justify-center gap-2 rounded-full border border-white/20 bg-white/5 px-6 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-white/10",
								children: "Manage tutors"
							})]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
				children: statCards.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: s.to,
					className: "group card-surface card-surface-hover block p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `flex h-11 w-11 items-center justify-center rounded-xl ${s.tile}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(s.icon, { className: "h-5 w-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "h-4 w-4 text-muted-foreground/40 transition-colors group-hover:text-primary" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 font-display text-3xl font-bold tabular-nums text-ink",
							children: stats.isLoading || s.value == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "inline-block h-7 w-12 animate-pulse rounded-md bg-surface-2 align-middle" }) : s.value
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground",
							children: s.label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-0.5 text-xs text-muted-foreground/70",
							children: s.hint
						})
					]
				}, s.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 lg:grid-cols-[2fr_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-surface p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex h-9 w-9 items-center justify-center rounded-lg bg-primary-soft text-primary shrink-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-4.5 w-4.5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-lg font-bold text-ink",
									children: "Recent applications"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Newest tutors awaiting review"
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/admin/applications",
							className: "inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline whitespace-nowrap",
							children: ["View all ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3.5 w-3.5" })]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "text-left text-[11px] uppercase tracking-wider text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3 font-semibold",
										children: "Applicant"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3 font-semibold",
										children: "Subject"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3 font-semibold",
										children: "Status"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3 font-semibold text-right",
										children: "Submitted"
									})
								]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
								pendingApps.slice(0, 6).map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t border-border transition-colors hover:bg-surface-2/70",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-3 pr-3",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "flex h-9 w-9 items-center justify-center rounded-full bg-primary-soft text-xs font-bold text-primary shrink-0",
													children: initials(x.full_name)
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "min-w-0",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "truncate font-semibold text-ink",
														children: x.full_name
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "truncate max-w-[200px] text-xs text-muted-foreground",
														children: x.professional_title
													})]
												})]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-3 pr-3",
											children: x.subjects?.[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "inline-flex items-center rounded-full bg-surface-2 px-2.5 py-1 text-xs font-medium text-ink",
												children: x.subjects[0]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground",
												children: "—"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-3 pr-3",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: x.status })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-3 pr-3 text-right text-xs text-muted-foreground whitespace-nowrap",
											children: timeAgo(x.created_at)
										})
									]
								}, x.id)),
								apps.isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									colSpan: 4,
									className: "py-10 text-center text-sm text-muted-foreground",
									children: "Loading applications…"
								}) }),
								!apps.isLoading && pendingApps.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									colSpan: 4,
									className: "py-12 text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inbox, { className: "mx-auto h-8 w-8 text-muted-foreground/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm text-muted-foreground",
										children: "No applications in the queue."
									})]
								}) })
							] })]
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-surface p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex h-9 w-9 items-center justify-center rounded-lg bg-gold-soft text-[oklch(0.42_0.10_75)]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "h-4.5 w-4.5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-lg font-bold text-ink",
								children: "Top tutors"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/admin/tutors",
							className: "text-xs font-semibold text-primary hover:underline",
							children: "View all"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-5 space-y-1",
						children: [topTutors.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3 rounded-xl p-2 transition-colors hover:bg-surface-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `flex h-6 w-6 items-center justify-center rounded-full text-[11px] font-bold shrink-0 ${i === 0 ? "bg-gold text-gold-foreground" : i === 1 ? "bg-primary-soft text-primary" : "bg-surface-2 text-muted-foreground"}`,
									children: i + 1
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-primary to-secondary text-xs font-bold text-white shrink-0",
									children: initials(t.name)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "truncate text-sm font-semibold text-ink",
										children: t.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "truncate text-xs text-muted-foreground",
										children: [t.subjects?.[0], t.curriculums?.[0]].filter(Boolean).join(" · ") || "—"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "inline-flex items-center gap-1 text-sm font-semibold text-[oklch(0.42_0.10_75)]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "h-3.5 w-3.5 fill-current text-gold" }),
										" ",
										t.rating ?? "—"
									]
								})
							]
						}, t.id)), !tutors.isLoading && topTutors.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "py-6 text-center text-sm text-muted-foreground",
							children: "No tutors yet — approve an application to publish one."
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-surface p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-9 w-9 items-center justify-center rounded-lg bg-primary-soft text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "h-4.5 w-4.5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-bold text-ink",
							children: "Recruitment pipeline"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Application outcomes to date"
						})] })]
					}), a ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-col items-center gap-6 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApprovalRing, {
							approved: a.approved,
							total: a.approved + a.pending + a.rejected
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "w-full flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PipelineBar, {
								approved: a.approved,
								pending: a.pending,
								rejected: a.rejected
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-4 space-y-2 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegendRow, {
										color: "bg-emerald-500",
										label: "Approved",
										value: a.approved
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegendRow, {
										color: "bg-amber-400",
										label: "In review",
										value: a.pending
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegendRow, {
										color: "bg-rose-500",
										label: "Rejected",
										value: a.rejected
									})
								]
							})]
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-6 h-32 animate-pulse rounded-2xl bg-surface-2" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-surface p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex h-9 w-9 items-center justify-center rounded-lg bg-sky-100 text-sky-700",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { className: "h-4.5 w-4.5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-lg font-bold text-ink",
								children: "Latest messages"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/admin/messages",
							className: "text-xs font-semibold text-primary hover:underline",
							children: "View all"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-5 space-y-1",
						children: [latestMessages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start gap-3 rounded-xl p-3 transition-colors hover:bg-surface-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex h-9 w-9 items-center justify-center rounded-full bg-surface-2 text-xs font-bold text-ink shrink-0",
									children: initials(m.name)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate text-sm font-semibold text-ink",
											children: m.name
										}), m.status === "unread" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "h-2 w-2 rounded-full bg-gold shrink-0",
											title: "Unread"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "truncate text-xs text-muted-foreground",
										children: m.subject || m.message
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted-foreground shrink-0 whitespace-nowrap",
									children: timeAgo(m.created_at)
								})
							]
						}, m.id)), !msgs.isLoading && latestMessages.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "py-6 text-center text-sm text-muted-foreground",
							children: "No messages yet."
						})]
					})]
				})]
			})
		]
	});
}
function capitalize(s) {
	return s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
}
function initials(name) {
	if (!name) return "?";
	return name.trim().split(/\s+/).map((p) => p[0]).slice(0, 2).join("").toUpperCase();
}
function timeAgo(iso) {
	if (!iso) return "—";
	const then = new Date(iso).getTime();
	if (Number.isNaN(then)) return "—";
	const mins = Math.round((Date.now() - then) / 6e4);
	if (mins < 1) return "just now";
	if (mins < 60) return `${mins}m ago`;
	const hrs = Math.round(mins / 60);
	if (hrs < 24) return `${hrs}h ago`;
	const days = Math.round(hrs / 24);
	if (days < 30) return `${days}d ago`;
	return new Date(iso).toLocaleDateString();
}
function ApprovalRing({ approved, total }) {
	const pct = total > 0 ? Math.round(approved / total * 100) : 0;
	const r = 42;
	const circ = 2 * Math.PI * r;
	const dash = pct / 100 * circ;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-32 w-32 shrink-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 100 100",
			className: "h-full w-full -rotate-90",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "50",
					cy: "50",
					r,
					fill: "none",
					stroke: "var(--color-surface-2)",
					strokeWidth: "10"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "50",
					cy: "50",
					r,
					fill: "none",
					stroke: "url(#ring-grad)",
					strokeWidth: "10",
					strokeLinecap: "round",
					strokeDasharray: `${dash} ${circ - dash}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
					id: "ring-grad",
					x1: "0",
					y1: "0",
					x2: "1",
					y2: "1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
						offset: "0%",
						stopColor: "var(--color-primary)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
						offset: "100%",
						stopColor: "var(--color-secondary)"
					})]
				}) })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute inset-0 flex flex-col items-center justify-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "font-display text-2xl font-bold text-ink tabular-nums",
				children: [pct, "%"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[10px] uppercase tracking-wider text-muted-foreground",
				children: "Approved"
			})]
		})]
	});
}
function PipelineBar({ approved, pending, rejected }) {
	const total = approved + pending + rejected;
	const w = (n) => total > 0 ? `${n / total * 100}%` : "0%";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-3 w-full overflow-hidden rounded-full bg-surface-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full bg-emerald-500",
				style: { width: w(approved) }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full bg-amber-400",
				style: { width: w(pending) }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full bg-rose-500",
				style: { width: w(rejected) }
			})
		]
	});
}
function LegendRow({ color, label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-center justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex items-center gap-2 text-muted-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-2.5 w-2.5 rounded-full ${color}` }),
				" ",
				label
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-semibold text-ink tabular-nums",
			children: value
		})]
	});
}
function StatusBadge({ status }) {
	const s = String(status ?? "").toLowerCase();
	const tone = s === "active" || s === "approved" ? "bg-emerald-50 text-emerald-700" : s === "pending" || s === "review" || s === "new" || s === "unread" || s === "trial" ? "bg-amber-50 text-amber-700" : s === "interview" ? "bg-blue-50 text-blue-700" : s === "rejected" || s === "paused" || s === "cancelled" ? "bg-rose-50 text-rose-700" : s === "removed" ? "bg-slate-200 text-slate-700" : "bg-slate-100 text-slate-700";
	const label = status === "removed" ? "Removed" : status;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold ${tone}`,
		children: label
	});
}
//#endregion
export { StatusBadge, AdminHome as component };
