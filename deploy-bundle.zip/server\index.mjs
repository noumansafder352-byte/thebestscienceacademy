globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as serve, i as defineLazyEventHandler, n as HTTPError, r as defineHandler, s as NodeResponse, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/image/fbise.png": {
		"type": "image/png",
		"etag": "\"1d927-FBhOcOBYRoOD3d8ni77ncyw5Bus\"",
		"mtime": "2026-07-23T18:11:10.345Z",
		"size": 121127,
		"path": "../public/image/fbise.png"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"19-yHADZo6lKl+mSNPU9098EiqzPCE\"",
		"mtime": "2026-07-22T14:14:52.591Z",
		"size": 25,
		"path": "../public/robots.txt"
	},
	"/image/Final-logo.png": {
		"type": "image/png",
		"etag": "\"1a80-yiJbc41XQmyvjW/rKRHt5JUgBl8\"",
		"mtime": "2026-07-23T18:11:10.338Z",
		"size": 6784,
		"path": "../public/image/Final-logo.png"
	},
	"/image/aqa.png": {
		"type": "image/png",
		"etag": "\"19e50-Kgv/dsGXYrk1CnL6+yA3kGDWBZ8\"",
		"mtime": "2026-07-23T18:11:10.345Z",
		"size": 106064,
		"path": "../public/image/aqa.png"
	},
	"/image/edexcel.png": {
		"type": "image/png",
		"etag": "\"372b5-MqavaVfS0VQ3Nw1JIeCA0B2O+Yk\"",
		"mtime": "2026-07-23T18:11:10.345Z",
		"size": 225973,
		"path": "../public/image/edexcel.png"
	},
	"/image/lrn.png": {
		"type": "image/png",
		"etag": "\"2a8f-uMiTIlxrKAgQRwf3/Q3UkuugxKk\"",
		"mtime": "2026-07-23T18:11:10.349Z",
		"size": 10895,
		"path": "../public/image/lrn.png"
	},
	"/image/ib.png": {
		"type": "image/png",
		"etag": "\"29821-oHD8VI3VogrpuujvGHCxn0Uvnis\"",
		"mtime": "2026-07-23T18:11:10.349Z",
		"size": 170017,
		"path": "../public/image/ib.png"
	},
	"/assets/about-DlGfXXh4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3f31-Uu5hEvt9+7X0iOYeHWXLmgif1KM\"",
		"mtime": "2026-07-25T18:36:07.730Z",
		"size": 16177,
		"path": "../public/assets/about-DlGfXXh4.js"
	},
	"/assets/admin-8BoajogV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a84-lYpnQcMtu83VbqzdErnZVqt5gAE\"",
		"mtime": "2026-07-25T18:36:07.730Z",
		"size": 6788,
		"path": "../public/assets/admin-8BoajogV.js"
	},
	"/assets/admin-ui-K3zxwhBu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e11-Osrl1lpnzRtw2mIU+mkO9a4VMx0\"",
		"mtime": "2026-07-25T18:36:07.730Z",
		"size": 3601,
		"path": "../public/assets/admin-ui-K3zxwhBu.js"
	},
	"/assets/admin.applications-l6xe71oE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4a07-MDj2FjS2H6NovW6vjR4xBC9r1qE\"",
		"mtime": "2026-07-25T18:36:07.730Z",
		"size": 18951,
		"path": "../public/assets/admin.applications-l6xe71oE.js"
	},
	"/assets/admin.index-CNEFM6dW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3eb1-ydILvAhT6k1YLqlpdO/4dhWkvtc\"",
		"mtime": "2026-07-25T18:36:07.730Z",
		"size": 16049,
		"path": "../public/assets/admin.index-CNEFM6dW.js"
	},
	"/assets/admin.login-Cj9SJZgX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ce0-qd+x43ZJP15+Yct50L92egNMUrY\"",
		"mtime": "2026-07-25T18:36:07.730Z",
		"size": 3296,
		"path": "../public/assets/admin.login-Cj9SJZgX.js"
	},
	"/assets/admin.messages-DAKdt6m3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2589-cEzPGbViD2Tw0NH2XqlbcSFdLvA\"",
		"mtime": "2026-07-25T18:36:07.739Z",
		"size": 9609,
		"path": "../public/assets/admin.messages-DAKdt6m3.js"
	},
	"/assets/admin.settings-BIjsGvzO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12f6-2JsLSb+f8ScxGjFxZa7sRwv8de8\"",
		"mtime": "2026-07-25T18:36:07.739Z",
		"size": 4854,
		"path": "../public/assets/admin.settings-BIjsGvzO.js"
	},
	"/assets/admin.students-CZWdGUIJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e8a-KWEM66Ph8aPmoUmFcByEjo2EQpk\"",
		"mtime": "2026-07-25T18:36:07.739Z",
		"size": 3722,
		"path": "../public/assets/admin.students-CZWdGUIJ.js"
	},
	"/assets/admin.tutors-D_Nqbvw5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ad4-cFQ9qpdF+K+8huNSjzsNMkCvxno\"",
		"mtime": "2026-07-25T18:36:07.740Z",
		"size": 6868,
		"path": "../public/assets/admin.tutors-D_Nqbvw5.js"
	},
	"/assets/admin.tutors._id.edit-Bye2JtR3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"383c-hveNSYUl+0jaA8HmMtLBiuxgfwY\"",
		"mtime": "2026-07-25T18:36:07.740Z",
		"size": 14396,
		"path": "../public/assets/admin.tutors._id.edit-Bye2JtR3.js"
	},
	"/assets/arrow-right-Z0TkZNJ-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-GHbyFi59SAeSZ8YJld9siVLCy9U\"",
		"mtime": "2026-07-25T18:36:07.741Z",
		"size": 165,
		"path": "../public/assets/arrow-right-Z0TkZNJ-.js"
	},
	"/assets/award-B6uR1ju1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"112-eu8XeULJVr24JoV8nvsoamnmgMI\"",
		"mtime": "2026-07-25T18:36:07.741Z",
		"size": 274,
		"path": "../public/assets/award-B6uR1ju1.js"
	},
	"/assets/become-a-tutor-BnoB4YW9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6855-slwa2RRqJ3f0lq2o4Xefe4OLvWU\"",
		"mtime": "2026-07-25T18:36:07.741Z",
		"size": 26709,
		"path": "../public/assets/become-a-tutor-BnoB4YW9.js"
	},
	"/assets/book-open-UkXeFNbm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"117-i212PZv8ZT8/fZahXLkdjeo4hjI\"",
		"mtime": "2026-07-25T18:36:07.741Z",
		"size": 279,
		"path": "../public/assets/book-open-UkXeFNbm.js"
	},
	"/image/oalevels.png": {
		"type": "image/png",
		"etag": "\"6dcc-hm03xaBQt3WJy79+cFq3AC61Czs\"",
		"mtime": "2026-07-23T18:11:10.349Z",
		"size": 28108,
		"path": "../public/image/oalevels.png"
	},
	"/image/igcse.png": {
		"type": "image/png",
		"etag": "\"121aa-LG2vxH+jMnKdqTG82sEQzlS0TAQ\"",
		"mtime": "2026-07-23T18:11:10.349Z",
		"size": 74154,
		"path": "../public/image/igcse.png"
	},
	"/image/The-Best-Science-Academy-White-Theme.png": {
		"type": "image/png",
		"etag": "\"1165-Zi1oeiMmTPyF96pL4hYNsyFf/cE\"",
		"mtime": "2026-07-23T18:11:10.338Z",
		"size": 4453,
		"path": "../public/image/The-Best-Science-Academy-White-Theme.png"
	},
	"/assets/briefcase-CTtcxH_h.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dc-YomWIRVbxGu78qD/IK8ZZGDwzi8\"",
		"mtime": "2026-07-25T18:36:07.742Z",
		"size": 220,
		"path": "../public/assets/briefcase-CTtcxH_h.js"
	},
	"/assets/calendar-clock-CXjDc1Jv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"17a-Zf039eqx9oGrVlsuWfjo/BinH4Q\"",
		"mtime": "2026-07-25T18:36:07.742Z",
		"size": 378,
		"path": "../public/assets/calendar-clock-CXjDc1Jv.js"
	},
	"/assets/chart-line-BoOGV_Gq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b8-ni0hsLNR6xPpWnfgpKjCTw2fydY\"",
		"mtime": "2026-07-25T18:36:07.746Z",
		"size": 184,
		"path": "../public/assets/chart-line-BoOGV_Gq.js"
	},
	"/assets/chevron-down-Bc7qjiwm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"80-aJan8aImZVuZOaRpBePm2zZ1k9o\"",
		"mtime": "2026-07-25T18:36:07.746Z",
		"size": 128,
		"path": "../public/assets/chevron-down-Bc7qjiwm.js"
	},
	"/assets/chevron-up-B4FDPRzi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"80-MmSuirF4647qEIHmjkGHGA90/gc\"",
		"mtime": "2026-07-25T18:36:07.746Z",
		"size": 128,
		"path": "../public/assets/chevron-up-B4FDPRzi.js"
	},
	"/assets/circle-check-D18l1LKx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b2-T2b035FZ80LN2z5kPcIWyUD7UuA\"",
		"mtime": "2026-07-25T18:36:07.746Z",
		"size": 178,
		"path": "../public/assets/circle-check-D18l1LKx.js"
	},
	"/assets/clock-DEEh0oyh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a9-7TyQ+GzpQYQLDqOa+/6XIa+yVZI\"",
		"mtime": "2026-07-25T18:36:07.746Z",
		"size": 169,
		"path": "../public/assets/clock-DEEh0oyh.js"
	},
	"/assets/contact-LMNqifj2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1cf7-yX1yzKzYuO7pzaRHHafWlidWF9c\"",
		"mtime": "2026-07-25T18:36:07.746Z",
		"size": 7415,
		"path": "../public/assets/contact-LMNqifj2.js"
	},
	"/assets/createLucideIcon-BXvMJD5C.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4ab-/dNlvL1ywJIPJEWLEQ9DO9WblhM\"",
		"mtime": "2026-07-25T18:36:07.746Z",
		"size": 1195,
		"path": "../public/assets/createLucideIcon-BXvMJD5C.js"
	},
	"/assets/createMiddleware-Bi-ToyvZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7f28-aN1uwmicUmOSbP+NsO609D6GMHI\"",
		"mtime": "2026-07-25T18:36:07.749Z",
		"size": 32552,
		"path": "../public/assets/createMiddleware-Bi-ToyvZ.js"
	},
	"/assets/graduation-cap-J7NItMB1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14c-YYU/oBThBbfBV+r84576Goqj4Vc\"",
		"mtime": "2026-07-25T18:36:07.749Z",
		"size": 332,
		"path": "../public/assets/graduation-cap-J7NItMB1.js"
	},
	"/assets/file-text-Bcu5lp4X.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"181-KTYrNwsWTKsySpROXwFvRF8Wuls\"",
		"mtime": "2026-07-25T18:36:07.749Z",
		"size": 385,
		"path": "../public/assets/file-text-Bcu5lp4X.js"
	},
	"/assets/inbox-CcEz9Dk7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11e-OpUqpdXDIS55MelzsF4qnHwmpXg\"",
		"mtime": "2026-07-25T18:36:07.749Z",
		"size": 286,
		"path": "../public/assets/inbox-CcEz9Dk7.js"
	},
	"/assets/invariant-DEEwAagU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3c-eVh/3DMi1s3cxf4N/OJar+ew1jA\"",
		"mtime": "2026-07-25T18:36:07.749Z",
		"size": 60,
		"path": "../public/assets/invariant-DEEwAagU.js"
	},
	"/assets/hero-tutor-BV9Hb4ag.jpg": {
		"type": "image/jpeg",
		"etag": "\"1d19f-P5nDD8ATU0rfXy2Sy4eEokirvVU\"",
		"mtime": "2026-07-25T18:36:07.785Z",
		"size": 119199,
		"path": "../public/assets/hero-tutor-BV9Hb4ag.jpg"
	},
	"/assets/jsx-runtime-BKllkxft.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"20d8-OsELDERtTmr6S+CCOADMMZjtZ2o\"",
		"mtime": "2026-07-25T18:36:07.749Z",
		"size": 8408,
		"path": "../public/assets/jsx-runtime-BKllkxft.js"
	},
	"/assets/languages-01YJk1tV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13c-dc0Kcyr5V9i3TdhZ8iAhcww34ko\"",
		"mtime": "2026-07-25T18:36:07.749Z",
		"size": 316,
		"path": "../public/assets/languages-01YJk1tV.js"
	},
	"/assets/layout-Bj4iSMSL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2906-2kYjAA4mn79QlnGA6hDBEoVoZfA\"",
		"mtime": "2026-07-25T18:36:07.751Z",
		"size": 10502,
		"path": "../public/assets/layout-Bj4iSMSL.js"
	},
	"/assets/link-mFHLnSDd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6889-9DaaB3PVTIOvQvHKDoeoOO0Yt5c\"",
		"mtime": "2026-07-25T18:36:07.751Z",
		"size": 26761,
		"path": "../public/assets/link-mFHLnSDd.js"
	},
	"/assets/mail-C_YLukyU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d5-iRWyy6QvkqKrbxssiL3zgafhb+Q\"",
		"mtime": "2026-07-25T18:36:07.751Z",
		"size": 213,
		"path": "../public/assets/mail-C_YLukyU.js"
	},
	"/assets/map-pin-CL9IWESl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"103-IwPOzJK1X6iG6lf5Iyet9ivMxd8\"",
		"mtime": "2026-07-25T18:36:07.751Z",
		"size": 259,
		"path": "../public/assets/map-pin-CL9IWESl.js"
	},
	"/assets/menu-BomqNm_g.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bd-ZUL66UYRmWKU2P6a42vhjp1cQCU\"",
		"mtime": "2026-07-25T18:36:07.751Z",
		"size": 189,
		"path": "../public/assets/menu-BomqNm_g.js"
	},
	"/assets/index-DWL_hBUB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"78a62-8K7M8QxdGvrq3N2VNcCeK2rX9/8\"",
		"mtime": "2026-07-25T18:36:07.730Z",
		"size": 494178,
		"path": "../public/assets/index-DWL_hBUB.js"
	},
	"/assets/message-square-gEmtwCk-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e9-BBsz4WVBp1+Q6Lm4dTr8S7EOPWE\"",
		"mtime": "2026-07-25T18:36:07.751Z",
		"size": 233,
		"path": "../public/assets/message-square-gEmtwCk-.js"
	},
	"/assets/message-circle-Cq5iVOcg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f1-EWivNOdYwrOnzwoLRC86XN/LMDE\"",
		"mtime": "2026-07-25T18:36:07.751Z",
		"size": 241,
		"path": "../public/assets/message-circle-Cq5iVOcg.js"
	},
	"/assets/page-header-DFErhD4s.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2f3-oTJfjCz8t4YTY3H+W2leZ4pYsm8\"",
		"mtime": "2026-07-25T18:36:07.751Z",
		"size": 755,
		"path": "../public/assets/page-header-DFErhD4s.js"
	},
	"/assets/phone-DDGd0qcY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"142-d54TcwDMfqC+F/OuUHztxg/eUNo\"",
		"mtime": "2026-07-25T18:36:07.753Z",
		"size": 322,
		"path": "../public/assets/phone-DDGd0qcY.js"
	},
	"/assets/phone-field-Rkh5BCSq.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"c89-KZugZhsOWhu6+xhEzF/3jMsNTO0\"",
		"mtime": "2026-07-25T18:36:07.785Z",
		"size": 3209,
		"path": "../public/assets/phone-field-Rkh5BCSq.css"
	},
	"/assets/programs-BV1g6bd8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"187a-qwM4LCa5zEQtbCHEBWZ5QXI8HGQ\"",
		"mtime": "2026-07-25T18:36:07.753Z",
		"size": 6266,
		"path": "../public/assets/programs-BV1g6bd8.js"
	},
	"/assets/privacy-DHC0Ay0B.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7c2-3YEXd6pE5Nu3c/L2Kh0xIUcvjw8\"",
		"mtime": "2026-07-25T18:36:07.753Z",
		"size": 1986,
		"path": "../public/assets/privacy-DHC0Ay0B.js"
	},
	"/assets/routes-xBfjcPu6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7b8a-Ep3iVrPpx9kIhyldyGr45QnvbRg\"",
		"mtime": "2026-07-25T18:36:07.755Z",
		"size": 31626,
		"path": "../public/assets/routes-xBfjcPu6.js"
	},
	"/assets/phone-field-N7DnQ4eI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"31e45-2vLwa+EHbtd+UnWOHV4Yx7qv97E\"",
		"mtime": "2026-07-25T18:36:07.753Z",
		"size": 204357,
		"path": "../public/assets/phone-field-N7DnQ4eI.js"
	},
	"/assets/settings-CprxVQ9_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e7-2hExDGRvh9RAkiwYc87elpUU0MM\"",
		"mtime": "2026-07-25T18:36:07.755Z",
		"size": 487,
		"path": "../public/assets/settings-CprxVQ9_.js"
	},
	"/assets/search-Cc-yeZA1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ae-dR8qk+sKmzDy01XWu8zC4CQAANY\"",
		"mtime": "2026-07-25T18:36:07.755Z",
		"size": 174,
		"path": "../public/assets/search-Cc-yeZA1.js"
	},
	"/assets/sigma-BIy93miL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e81-vF0nKYhCjdxMT7RmQvitXoOmaZA\"",
		"mtime": "2026-07-25T18:36:07.755Z",
		"size": 3713,
		"path": "../public/assets/sigma-BIy93miL.js"
	},
	"/assets/site-data-B6sOkp_r.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2aa5-TycAJx98G/IaLOX5K8czZ8oYsbo\"",
		"mtime": "2026-07-25T18:36:07.755Z",
		"size": 10917,
		"path": "../public/assets/site-data-B6sOkp_r.js"
	},
	"/assets/sparkles-CCVl1gRM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ee-2PuHozw4K4iIeeAuA/3XkuyXjRk\"",
		"mtime": "2026-07-25T18:36:07.755Z",
		"size": 494,
		"path": "../public/assets/sparkles-CCVl1gRM.js"
	},
	"/assets/star-DGg3hN1W.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d8-U6i2WxvZ2Gj1XXau0jgRimuY9Uo\"",
		"mtime": "2026-07-25T18:36:07.755Z",
		"size": 472,
		"path": "../public/assets/star-DGg3hN1W.js"
	},
	"/assets/shield-check-DkvtW4EV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"140-gS/gHfr1l8eFU2FwlZzAuX/2KEY\"",
		"mtime": "2026-07-25T18:36:07.755Z",
		"size": 320,
		"path": "../public/assets/shield-check-DkvtW4EV.js"
	},
	"/assets/subjects-BaYnAQwu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b83-vvhUamxLiX1H++20Rg0n/KMDZkU\"",
		"mtime": "2026-07-25T18:36:07.757Z",
		"size": 2947,
		"path": "../public/assets/subjects-BaYnAQwu.js"
	},
	"/assets/terms-w5qkoAHI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7fb-KIi9AfTAuoeDg18z/3ik1C2hQHM\"",
		"mtime": "2026-07-25T18:36:07.757Z",
		"size": 2043,
		"path": "../public/assets/terms-w5qkoAHI.js"
	},
	"/assets/triangle-alert-BZIDuJIl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"21c-Ih2xvUbttPBqfmw7d9BSXIdgzhY\"",
		"mtime": "2026-07-25T18:36:07.757Z",
		"size": 540,
		"path": "../public/assets/triangle-alert-BZIDuJIl.js"
	},
	"/assets/tutor-1-DAQcHp1E.jpg": {
		"type": "image/jpeg",
		"etag": "\"ca02-H9PO+P4yJCTq2b/yOeJbmtjm/L4\"",
		"mtime": "2026-07-25T18:36:07.785Z",
		"size": 51714,
		"path": "../public/assets/tutor-1-DAQcHp1E.jpg"
	},
	"/assets/styles-yGPC_jr5.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"23658-Bf/jp+VxZbd0/TeJ5ib1GuxsSwA\"",
		"mtime": "2026-07-25T18:36:07.785Z",
		"size": 144984,
		"path": "../public/assets/styles-yGPC_jr5.css"
	},
	"/assets/tutor-2-CZ-4SZ3x.jpg": {
		"type": "image/jpeg",
		"etag": "\"c4a7-Ju+duBmM8iOpHC4+XPn31ET772E\"",
		"mtime": "2026-07-25T18:36:07.785Z",
		"size": 50343,
		"path": "../public/assets/tutor-2-CZ-4SZ3x.jpg"
	},
	"/assets/tutor-4-DlR4AUL1.jpg": {
		"type": "image/jpeg",
		"etag": "\"a30e-8WzADgr7FZLmp0oNJitqxX3OPg4\"",
		"mtime": "2026-07-25T18:36:07.787Z",
		"size": 41742,
		"path": "../public/assets/tutor-4-DlR4AUL1.jpg"
	},
	"/assets/tutor-api.functions-BD5oeCGk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f29-VYmsp+FMC85IIZVcLO7AnrA9K0Q\"",
		"mtime": "2026-07-25T18:36:07.759Z",
		"size": 7977,
		"path": "../public/assets/tutor-api.functions-BD5oeCGk.js"
	},
	"/assets/tutor-3-JZxrA56-.jpg": {
		"type": "image/jpeg",
		"etag": "\"11780-ZcIdaiLO7u4CU2TsRq04/DPS380\"",
		"mtime": "2026-07-25T18:36:07.787Z",
		"size": 71552,
		"path": "../public/assets/tutor-3-JZxrA56-.jpg"
	},
	"/assets/tutor-badges-H4m22SCV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6e0c-3YmYFX2MIvfKm9tJlzd9GrFUb4A\"",
		"mtime": "2026-07-25T18:36:07.759Z",
		"size": 28172,
		"path": "../public/assets/tutor-badges-H4m22SCV.js"
	},
	"/assets/tutor-card-CQ0MEMuw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"938-hw28iEVfcl3IJVldb6nPI0VAg1I\"",
		"mtime": "2026-07-25T18:36:07.759Z",
		"size": 2360,
		"path": "../public/assets/tutor-card-CQ0MEMuw.js"
	},
	"/assets/tutors.index-CEVA234P.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12fb-7KSmmCUp3Kue+AuYl7p/7XUWkh4\"",
		"mtime": "2026-07-25T18:36:07.759Z",
		"size": 4859,
		"path": "../public/assets/tutors.index-CEVA234P.js"
	},
	"/assets/tutors._slug-BzHNQQbp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"223-/2vTefpVCCXNR/PQr1vQjQLr93s\"",
		"mtime": "2026-07-25T18:36:07.759Z",
		"size": 547,
		"path": "../public/assets/tutors._slug-BzHNQQbp.js"
	},
	"/assets/tutors._slug-BZF33mz7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b3-zDPJF9bTkvYuumEqZym/jAK9J4U\"",
		"mtime": "2026-07-25T18:36:07.759Z",
		"size": 435,
		"path": "../public/assets/tutors._slug-BZF33mz7.js"
	},
	"/assets/tutors._slug-DdJ3V-9D.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3194-rSUO8kmODtkSfxWnHQ5jHsSV1W0\"",
		"mtime": "2026-07-25T18:36:07.759Z",
		"size": 12692,
		"path": "../public/assets/tutors._slug-DdJ3V-9D.js"
	},
	"/assets/use-auth-CPwYWh0c.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d8-VAPzItRdheWj3O6ajVMT6frVHAY\"",
		"mtime": "2026-07-25T18:36:07.774Z",
		"size": 472,
		"path": "../public/assets/use-auth-CPwYWh0c.js"
	},
	"/assets/upload-yE3nZfWN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e6-HkrUAZbEkV7TvlQtgzawl5e12pA\"",
		"mtime": "2026-07-25T18:36:07.762Z",
		"size": 230,
		"path": "../public/assets/upload-yE3nZfWN.js"
	},
	"/assets/useBaseQuery-Dv6ENYW6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2268-CgyNx7Jh5QPqWNrrjK01Xf7GZAw\"",
		"mtime": "2026-07-25T18:36:07.779Z",
		"size": 8808,
		"path": "../public/assets/useBaseQuery-Dv6ENYW6.js"
	},
	"/assets/useMatch-BUPz_TP8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2cc-nzRdG5NDscTLKeSlYOi7LUFRpnU\"",
		"mtime": "2026-07-25T18:36:07.780Z",
		"size": 716,
		"path": "../public/assets/useMatch-BUPz_TP8.js"
	},
	"/assets/useMutation-AAI4S_zK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8c5-fxrkecMXy90tE7E+UV6cxaLXvBw\"",
		"mtime": "2026-07-25T18:36:07.780Z",
		"size": 2245,
		"path": "../public/assets/useMutation-AAI4S_zK.js"
	},
	"/assets/useQuery-CLKELBIY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"60-CmX0lCZiNQsG+UsZ3FC84lgWi4Y\"",
		"mtime": "2026-07-25T18:36:07.783Z",
		"size": 96,
		"path": "../public/assets/useQuery-CLKELBIY.js"
	},
	"/assets/user-CkdSJxNd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c4-OYmkdEapEgvC4QDNqNOuMMn6oSA\"",
		"mtime": "2026-07-25T18:36:07.783Z",
		"size": 196,
		"path": "../public/assets/user-CkdSJxNd.js"
	},
	"/assets/useRouter-DQzVw-2q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"97-Kqlf0YLe9hHIesaV05RETSxmlWI\"",
		"mtime": "2026-07-25T18:36:07.783Z",
		"size": 151,
		"path": "../public/assets/useRouter-DQzVw-2q.js"
	},
	"/assets/users-CJ1EluYZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"132-w0lQwQxIC1Gf+zld4/NB6kjqF0s\"",
		"mtime": "2026-07-25T18:36:07.783Z",
		"size": 306,
		"path": "../public/assets/users-CJ1EluYZ.js"
	},
	"/assets/video-qRzbT2pd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f8-SDaGDTts1Z3V+2JR/qzKyXOnHdY\"",
		"mtime": "2026-07-25T18:36:07.783Z",
		"size": 248,
		"path": "../public/assets/video-qRzbT2pd.js"
	},
	"/assets/x-Br4Dstqh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9a-ArQb6OtH+hdYdbfNhBycHEIKtmE\"",
		"mtime": "2026-07-25T18:36:07.785Z",
		"size": 154,
		"path": "../public/assets/x-Br4Dstqh.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_OW4PNe = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_OW4PNe
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
