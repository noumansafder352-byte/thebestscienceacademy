import { i as useQuery, s as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { Ct as CalendarClock, Q as Inbox, a as Users, tt as GraduationCap } from "../_libs/lucide-react.mjs";
import { D as useServerFn, u as adminListBookings } from "./tutor-api.functions-BgQ4s39o.mjs";
import { n as StatusBadge } from "./admin.index-DDK7e_Tq.mjs";
import { c as tableRow, n as AdminPageHeader, o as StatTile, r as EmptyState, s as tableHeadRow, t as AdminAvatar } from "./admin-ui-EM48c1k2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.students-C4Ha0X0k.js
var import_jsx_runtime = require_jsx_runtime();
function StudentsAdmin() {
	const listFn = useServerFn(adminListBookings);
	const { data, isLoading } = useQuery({
		queryKey: ["admin-bookings"],
		queryFn: () => listFn()
	});
	const bookings = data ?? [];
	const weekAgo = Date.now() - 10080 * 60 * 1e3;
	const newThisWeek = bookings.filter((b) => new Date(b.created_at).getTime() >= weekAgo).length;
	const pending = bookings.filter((b) => (b.status ?? "").toLowerCase() === "pending" || (b.status ?? "").toLowerCase() === "trial").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminPageHeader, {
				icon: Users,
				title: "Students & trial bookings",
				subtitle: "Enquiries submitted through Book Free Trial and the contact form.",
				accent: "bg-emerald-100 text-emerald-700"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						icon: GraduationCap,
						label: "Total bookings",
						value: isLoading ? "—" : bookings.length,
						accent: "bg-primary-soft text-primary",
						hint: "All time"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						icon: CalendarClock,
						label: "New this week",
						value: isLoading ? "—" : newThisWeek,
						accent: "bg-emerald-100 text-emerald-700",
						hint: "Last 7 days"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						icon: Inbox,
						label: "Awaiting response",
						value: isLoading ? "—" : pending,
						accent: "bg-amber-100 text-amber-700",
						hint: "Pending / trial"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "card-surface p-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: tableHeadRow,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 pr-3 font-semibold",
									children: "Student"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 pr-3 font-semibold",
									children: "Parent / Email"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 pr-3 font-semibold",
									children: "Country"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 pr-3 font-semibold",
									children: "Curriculum"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 pr-3 font-semibold",
									children: "Subject"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 pr-3 font-semibold",
									children: "Submitted"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 pr-3 font-semibold",
									children: "Status"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
							bookings.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: tableRow,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 pr-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminAvatar, { name: s.student_name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-semibold text-ink",
												children: s.student_name
											})]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-3 pr-3 text-muted-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-ink",
											children: s.parent_name ?? "—"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs",
											children: s.email
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 pr-3 text-muted-foreground",
										children: s.country ?? "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 pr-3",
										children: s.curriculum ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "inline-flex items-center rounded-full bg-surface-2 px-2.5 py-1 text-xs font-medium text-ink",
											children: s.curriculum
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: "—"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 pr-3 text-muted-foreground",
										children: s.subject ?? "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 pr-3 text-muted-foreground whitespace-nowrap",
										children: new Date(s.created_at).toLocaleDateString()
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 pr-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s.status })
									})
								]
							}, s.id)),
							!isLoading && bookings.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 7,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
									icon: Inbox,
									title: "No bookings yet",
									hint: "Trial requests will appear here as they come in."
								})
							}) }),
							isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 7,
								className: "py-14 text-center text-sm text-muted-foreground",
								children: "Loading bookings…"
							}) })
						] })]
					})
				})
			})
		]
	});
}
//#endregion
export { StudentsAdmin as component };
