//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D6i9MJv1.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/the_science_academy_project/Science-Academy/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/admin",
			"/become-a-tutor",
			"/contact",
			"/privacy",
			"/programs",
			"/sitemap.xml",
			"/subjects",
			"/terms",
			"/tutors/$slug",
			"/tutors/"
		],
		preloads: [
			"/assets/index-DWL_hBUB.js",
			"/assets/jsx-runtime-BKllkxft.js",
			"/assets/link-mFHLnSDd.js",
			"/assets/createMiddleware-Bi-ToyvZ.js",
			"/assets/invariant-DEEwAagU.js",
			"/assets/useMatch-BUPz_TP8.js",
			"/assets/useRouter-DQzVw-2q.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DWL_hBUB.js"
		} }]
	},
	"/": {
		filePath: "D:/the_science_academy_project/Science-Academy/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-xBfjcPu6.js",
			"/assets/tutor-api.functions-BD5oeCGk.js",
			"/assets/useQuery-CLKELBIY.js",
			"/assets/createLucideIcon-BXvMJD5C.js",
			"/assets/arrow-right-Z0TkZNJ-.js",
			"/assets/sigma-BIy93miL.js",
			"/assets/book-open-UkXeFNbm.js",
			"/assets/briefcase-CTtcxH_h.js",
			"/assets/calendar-clock-CXjDc1Jv.js",
			"/assets/chart-line-BoOGV_Gq.js",
			"/assets/circle-check-D18l1LKx.js",
			"/assets/layout-Bj4iSMSL.js",
			"/assets/graduation-cap-J7NItMB1.js",
			"/assets/languages-01YJk1tV.js",
			"/assets/message-square-gEmtwCk-.js",
			"/assets/shield-check-DkvtW4EV.js",
			"/assets/sparkles-CCVl1gRM.js",
			"/assets/star-DGg3hN1W.js",
			"/assets/users-CJ1EluYZ.js",
			"/assets/video-qRzbT2pd.js",
			"/assets/site-data-B6sOkp_r.js",
			"/assets/tutor-card-CQ0MEMuw.js"
		]
	},
	"/about": {
		filePath: "D:/the_science_academy_project/Science-Academy/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-DlGfXXh4.js",
			"/assets/createLucideIcon-BXvMJD5C.js",
			"/assets/arrow-right-Z0TkZNJ-.js",
			"/assets/book-open-UkXeFNbm.js",
			"/assets/chart-line-BoOGV_Gq.js",
			"/assets/layout-Bj4iSMSL.js",
			"/assets/graduation-cap-J7NItMB1.js",
			"/assets/sparkles-CCVl1gRM.js",
			"/assets/page-header-DFErhD4s.js"
		]
	},
	"/admin": {
		filePath: "D:/the_science_academy_project/Science-Academy/src/routes/admin.tsx",
		children: [
			"/admin/applications",
			"/admin/login",
			"/admin/messages",
			"/admin/settings",
			"/admin/students",
			"/admin/tutors",
			"/admin/"
		],
		preloads: [
			"/assets/admin-8BoajogV.js",
			"/assets/tutor-api.functions-BD5oeCGk.js",
			"/assets/useQuery-CLKELBIY.js",
			"/assets/createLucideIcon-BXvMJD5C.js",
			"/assets/chevron-down-Bc7qjiwm.js",
			"/assets/file-text-Bcu5lp4X.js",
			"/assets/graduation-cap-J7NItMB1.js",
			"/assets/mail-C_YLukyU.js",
			"/assets/menu-BomqNm_g.js",
			"/assets/search-Cc-yeZA1.js",
			"/assets/settings-CprxVQ9_.js",
			"/assets/users-CJ1EluYZ.js",
			"/assets/x-Br4Dstqh.js",
			"/assets/use-auth-CPwYWh0c.js"
		]
	},
	"/become-a-tutor": {
		filePath: "D:/the_science_academy_project/Science-Academy/src/routes/become-a-tutor.tsx",
		children: void 0,
		css: ["/assets/phone-field-Rkh5BCSq.css"],
		preloads: [
			"/assets/become-a-tutor-BnoB4YW9.js",
			"/assets/tutor-api.functions-BD5oeCGk.js",
			"/assets/createLucideIcon-BXvMJD5C.js",
			"/assets/arrow-right-Z0TkZNJ-.js",
			"/assets/award-B6uR1ju1.js",
			"/assets/briefcase-CTtcxH_h.js",
			"/assets/circle-check-D18l1LKx.js",
			"/assets/clock-DEEh0oyh.js",
			"/assets/layout-Bj4iSMSL.js",
			"/assets/file-text-Bcu5lp4X.js",
			"/assets/graduation-cap-J7NItMB1.js",
			"/assets/mail-C_YLukyU.js",
			"/assets/phone-DDGd0qcY.js",
			"/assets/shield-check-DkvtW4EV.js",
			"/assets/sparkles-CCVl1gRM.js",
			"/assets/upload-yE3nZfWN.js",
			"/assets/user-CkdSJxNd.js",
			"/assets/users-CJ1EluYZ.js",
			"/assets/x-Br4Dstqh.js",
			"/assets/page-header-DFErhD4s.js",
			"/assets/phone-field-N7DnQ4eI.js"
		]
	},
	"/contact": {
		filePath: "D:/the_science_academy_project/Science-Academy/src/routes/contact.tsx",
		children: void 0,
		css: ["/assets/phone-field-Rkh5BCSq.css"],
		preloads: [
			"/assets/contact-LMNqifj2.js",
			"/assets/tutor-api.functions-BD5oeCGk.js",
			"/assets/arrow-right-Z0TkZNJ-.js",
			"/assets/circle-check-D18l1LKx.js",
			"/assets/clock-DEEh0oyh.js",
			"/assets/layout-Bj4iSMSL.js",
			"/assets/mail-C_YLukyU.js",
			"/assets/map-pin-CL9IWESl.js",
			"/assets/message-circle-Cq5iVOcg.js",
			"/assets/phone-DDGd0qcY.js",
			"/assets/page-header-DFErhD4s.js",
			"/assets/phone-field-N7DnQ4eI.js"
		]
	},
	"/privacy": {
		filePath: "D:/the_science_academy_project/Science-Academy/src/routes/privacy.tsx",
		children: void 0,
		preloads: [
			"/assets/privacy-DHC0Ay0B.js",
			"/assets/layout-Bj4iSMSL.js",
			"/assets/page-header-DFErhD4s.js"
		]
	},
	"/programs": {
		filePath: "D:/the_science_academy_project/Science-Academy/src/routes/programs.tsx",
		children: void 0,
		preloads: [
			"/assets/programs-BV1g6bd8.js",
			"/assets/arrow-right-Z0TkZNJ-.js",
			"/assets/chevron-down-Bc7qjiwm.js",
			"/assets/chevron-up-B4FDPRzi.js",
			"/assets/circle-check-D18l1LKx.js",
			"/assets/layout-Bj4iSMSL.js",
			"/assets/page-header-DFErhD4s.js",
			"/assets/site-data-B6sOkp_r.js"
		]
	},
	"/subjects": {
		filePath: "D:/the_science_academy_project/Science-Academy/src/routes/subjects.tsx",
		children: void 0,
		preloads: [
			"/assets/subjects-BaYnAQwu.js",
			"/assets/arrow-right-Z0TkZNJ-.js",
			"/assets/sigma-BIy93miL.js",
			"/assets/book-open-UkXeFNbm.js",
			"/assets/briefcase-CTtcxH_h.js",
			"/assets/chart-line-BoOGV_Gq.js",
			"/assets/layout-Bj4iSMSL.js",
			"/assets/languages-01YJk1tV.js",
			"/assets/message-square-gEmtwCk-.js",
			"/assets/users-CJ1EluYZ.js",
			"/assets/page-header-DFErhD4s.js",
			"/assets/site-data-B6sOkp_r.js"
		]
	},
	"/terms": {
		filePath: "D:/the_science_academy_project/Science-Academy/src/routes/terms.tsx",
		children: void 0,
		preloads: [
			"/assets/terms-w5qkoAHI.js",
			"/assets/layout-Bj4iSMSL.js",
			"/assets/page-header-DFErhD4s.js"
		]
	},
	"/admin/applications": {
		filePath: "D:/the_science_academy_project/Science-Academy/src/routes/admin.applications.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.applications-l6xe71oE.js",
			"/assets/useMutation-AAI4S_zK.js",
			"/assets/circle-check-D18l1LKx.js",
			"/assets/clock-DEEh0oyh.js",
			"/assets/inbox-CcEz9Dk7.js",
			"/assets/message-circle-Cq5iVOcg.js",
			"/assets/phone-DDGd0qcY.js",
			"/assets/triangle-alert-BZIDuJIl.js",
			"/assets/admin-ui-K3zxwhBu.js"
		]
	},
	"/admin/login": {
		filePath: "D:/the_science_academy_project/Science-Academy/src/routes/admin.login.tsx",
		children: void 0,
		preloads: ["/assets/admin.login-Cj9SJZgX.js", "/assets/shield-check-DkvtW4EV.js"]
	},
	"/admin/messages": {
		filePath: "D:/the_science_academy_project/Science-Academy/src/routes/admin.messages.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.messages-DAKdt6m3.js",
			"/assets/useMutation-AAI4S_zK.js",
			"/assets/inbox-CcEz9Dk7.js",
			"/assets/phone-DDGd0qcY.js",
			"/assets/triangle-alert-BZIDuJIl.js",
			"/assets/admin-ui-K3zxwhBu.js"
		]
	},
	"/admin/settings": {
		filePath: "D:/the_science_academy_project/Science-Academy/src/routes/admin.settings.tsx",
		children: void 0,
		preloads: ["/assets/admin.settings-BIjsGvzO.js", "/assets/admin-ui-K3zxwhBu.js"]
	},
	"/admin/students": {
		filePath: "D:/the_science_academy_project/Science-Academy/src/routes/admin.students.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.students-CZWdGUIJ.js",
			"/assets/calendar-clock-CXjDc1Jv.js",
			"/assets/inbox-CcEz9Dk7.js",
			"/assets/admin-ui-K3zxwhBu.js"
		]
	},
	"/admin/tutors": {
		filePath: "D:/the_science_academy_project/Science-Academy/src/routes/admin.tutors.tsx",
		children: ["/admin/tutors/$id/edit"],
		preloads: [
			"/assets/admin.tutors-D_Nqbvw5.js",
			"/assets/useMutation-AAI4S_zK.js",
			"/assets/inbox-CcEz9Dk7.js",
			"/assets/star-DGg3hN1W.js",
			"/assets/triangle-alert-BZIDuJIl.js",
			"/assets/admin-ui-K3zxwhBu.js"
		]
	},
	"/tutors/$slug": {
		filePath: "D:/the_science_academy_project/Science-Academy/src/routes/tutors.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/tutors._slug-BZF33mz7.js",
			"/assets/layout-Bj4iSMSL.js",
			"/assets/tutors._slug-BzHNQQbp.js",
			"/assets/tutors._slug-DdJ3V-9D.js",
			"/assets/tutor-api.functions-BD5oeCGk.js",
			"/assets/useBaseQuery-Dv6ENYW6.js",
			"/assets/createLucideIcon-BXvMJD5C.js",
			"/assets/arrow-right-Z0TkZNJ-.js",
			"/assets/award-B6uR1ju1.js",
			"/assets/book-open-UkXeFNbm.js",
			"/assets/chevron-down-Bc7qjiwm.js",
			"/assets/chevron-up-B4FDPRzi.js",
			"/assets/circle-check-D18l1LKx.js",
			"/assets/clock-DEEh0oyh.js",
			"/assets/graduation-cap-J7NItMB1.js",
			"/assets/languages-01YJk1tV.js",
			"/assets/map-pin-CL9IWESl.js",
			"/assets/message-square-gEmtwCk-.js",
			"/assets/shield-check-DkvtW4EV.js",
			"/assets/sparkles-CCVl1gRM.js",
			"/assets/star-DGg3hN1W.js",
			"/assets/user-CkdSJxNd.js",
			"/assets/video-qRzbT2pd.js",
			"/assets/tutor-badges-H4m22SCV.js"
		]
	},
	"/admin/": {
		filePath: "D:/the_science_academy_project/Science-Academy/src/routes/admin.index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.index-CNEFM6dW.js",
			"/assets/arrow-right-Z0TkZNJ-.js",
			"/assets/award-B6uR1ju1.js",
			"/assets/inbox-CcEz9Dk7.js",
			"/assets/message-square-gEmtwCk-.js",
			"/assets/sparkles-CCVl1gRM.js",
			"/assets/star-DGg3hN1W.js"
		]
	},
	"/tutors/": {
		filePath: "D:/the_science_academy_project/Science-Academy/src/routes/tutors.index.tsx",
		children: void 0,
		preloads: [
			"/assets/tutors.index-CEVA234P.js",
			"/assets/tutor-api.functions-BD5oeCGk.js",
			"/assets/useQuery-CLKELBIY.js",
			"/assets/createLucideIcon-BXvMJD5C.js",
			"/assets/layout-Bj4iSMSL.js",
			"/assets/search-Cc-yeZA1.js",
			"/assets/shield-check-DkvtW4EV.js",
			"/assets/sparkles-CCVl1gRM.js",
			"/assets/page-header-DFErhD4s.js",
			"/assets/tutor-card-CQ0MEMuw.js"
		]
	},
	"/admin/tutors/$id/edit": {
		filePath: "D:/the_science_academy_project/Science-Academy/src/routes/admin.tutors.$id.edit.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.tutors._id.edit-Bye2JtR3.js",
			"/assets/circle-check-D18l1LKx.js",
			"/assets/upload-yE3nZfWN.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
