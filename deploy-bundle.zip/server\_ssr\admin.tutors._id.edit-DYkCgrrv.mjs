import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.tutors._id.edit-DYkCgrrv.js
var $$splitComponentImporter = () => import("./admin.tutors._id.edit-DfcidDOQ.mjs");
var Route = createFileRoute("/admin/tutors/$id/edit")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
//#endregion
export { Route as t };
