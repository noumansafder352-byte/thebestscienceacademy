import { o as __toESM } from "../_runtime.mjs";
import { c as require_react, i as useQuery, s as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { _ as useNavigate, f as Outlet, g as Link, l as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { G as LayoutDashboard, H as LogOut, I as Menu, S as Search, a as Users, at as FileText, b as Settings, bt as ChevronDown, kt as Bell, n as X, tt as GraduationCap, z as Mail } from "../_libs/lucide-react.mjs";
import { D as useServerFn, x as getIsAdmin } from "./tutor-api.functions-B297e9FO.mjs";
import { t as supabase } from "./client-BrsPMyxW.mjs";
import { t as useAuth } from "./use-auth-B7VfCL3m.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-7K-JUZ0c.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var nav = [
	{
		to: "/admin",
		label: "Dashboard",
		icon: LayoutDashboard,
		exact: true
	},
	{
		to: "/admin/tutors",
		label: "Tutors",
		icon: GraduationCap
	},
	{
		to: "/admin/students",
		label: "Students",
		icon: Users
	},
	{
		to: "/admin/applications",
		label: "Applications",
		icon: FileText
	},
	{
		to: "/admin/messages",
		label: "Messages",
		icon: Mail
	},
	{
		to: "/admin/settings",
		label: "Settings",
		icon: Settings
	}
];
function AdminLayout() {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const navigate = useNavigate();
	const { user, loading } = useAuth();
	const isLoginRoute = pathname === "/admin/login";
	const [mobileNavOpen, setMobileNavOpen] = (0, import_react.useState)(false);
	const checkAdmin = useServerFn(getIsAdmin);
	const { data: adminCheck, isLoading: checkingAdmin } = useQuery({
		queryKey: ["is-admin", user?.id],
		queryFn: () => checkAdmin(),
		enabled: !!user && !isLoginRoute
	});
	(0, import_react.useEffect)(() => {
		if (isLoginRoute) return;
		if (loading) return;
		if (!user) navigate({ to: "/admin/login" });
	}, [
		loading,
		user,
		isLoginRoute,
		navigate
	]);
	(0, import_react.useEffect)(() => {
		setMobileNavOpen(false);
	}, [pathname]);
	if (isLoginRoute) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {});
	if (loading || user && checkingAdmin) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen flex items-center justify-center text-sm text-muted-foreground",
		children: "Loading…"
	});
	if (user && adminCheck && !adminCheck.isAdmin) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen flex items-center justify-center px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center card-surface p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "heading-md",
					children: "Not authorised"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm text-muted-foreground",
					children: [
						"Your account doesn't have admin access. Ask a super-admin to grant you the ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "admin" }),
						" role, then reload this page."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "btn-ghost mt-6",
					onClick: async () => {
						await supabase.auth.signOut();
						navigate({ to: "/admin/login" });
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-4 w-4" }), " Sign out"]
				})
			]
		})
	});
	const renderSidebar = (onNavigate) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-center justify-center border-b border-white/10 px-5 py-7",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/image/The-Best-Science-Academy-White-Theme.png",
				alt: "The Best Science Academy",
				className: "w-full max-w-[190px] object-contain"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "flex-1 space-y-1 overflow-y-auto p-3",
			children: nav.map((item) => {
				const active = item.exact ? pathname === item.to : pathname.startsWith(item.to);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: item.to,
					onClick: onNavigate,
					className: `flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${active ? "bg-white/10 text-white" : "text-white/70 hover:bg-white/5 hover:text-white"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "h-4 w-4" }), item.label]
				}, item.to);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2 border-t border-white/10 p-4 text-xs text-white/55",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				onClick: onNavigate,
				className: "block hover:text-gold",
				children: "← Back to website"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: async () => {
					onNavigate?.();
					await supabase.auth.signOut();
					navigate({ to: "/admin/login" });
				},
				className: "inline-flex items-center gap-1.5 hover:text-gold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-3 w-3" }), " Sign out"]
			})]
		})
	] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-screen bg-surface-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "hidden w-64 shrink-0 flex-col bg-ink text-white lg:flex",
				children: renderSidebar()
			}),
			mobileNavOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-50 lg:hidden",
				role: "dialog",
				"aria-modal": "true",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 bg-black/50",
					onClick: () => setMobileNavOpen(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "absolute inset-y-0 left-0 flex w-72 max-w-[82%] flex-col bg-ink text-white shadow-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setMobileNavOpen(false),
						"aria-label": "Close menu",
						className: "absolute right-3 top-3 z-10 flex h-9 w-9 items-center justify-center rounded-full text-white/70 hover:bg-white/10 hover:text-white",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
					}), renderSidebar(() => setMobileNavOpen(false))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex h-16 items-center justify-between gap-3 border-b border-border bg-surface px-4 lg:gap-4 lg:px-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 flex-1 items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setMobileNavOpen(true),
							"aria-label": "Open menu",
							className: "flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-border text-ink lg:hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-5 w-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative min-w-0 max-w-md flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								placeholder: "Search tutors, students, applications…",
								className: "h-10 w-full rounded-full border border-border bg-surface-2 pl-9 pr-4 text-sm outline-none focus:border-primary focus:bg-surface"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "relative flex h-10 w-10 items-center justify-center rounded-full border border-border",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute right-2 top-2 h-2 w-2 rounded-full bg-gold" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "flex h-10 items-center gap-2 rounded-full border border-border pl-1 pr-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-primary to-secondary text-xs font-bold text-white",
									children: user?.email?.[0]?.toUpperCase() ?? "A"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden max-w-[140px] truncate text-sm font-medium sm:inline",
									children: user?.email ?? "Admin"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4 text-muted-foreground" })
							]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "flex-1 p-5 lg:p-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
				})]
			})
		]
	});
}
//#endregion
export { AdminLayout as component };
