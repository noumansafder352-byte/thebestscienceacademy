import { s as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { A as Palette, S as Search, Tt as Building2, X as Info, b as Settings, z as Mail } from "../_libs/lucide-react.mjs";
import { n as AdminPageHeader } from "./admin-ui-EM48c1k2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.settings-DtkWPiYV.js
var import_jsx_runtime = require_jsx_runtime();
function SettingsAdmin() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-3xl space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminPageHeader, {
				icon: Settings,
				title: "Settings",
				subtitle: "Configure your academy's public presence and branding.",
				accent: "bg-slate-200 text-slate-700"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-amber-800",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "mt-0.5 h-4 w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: "These fields are a preview — they aren't connected to a data store yet, so saving won't change the live site."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-5",
				onSubmit: (e) => e.preventDefault(),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsCard, {
						icon: Building2,
						title: "Academy",
						description: "Your organisation's name and identity.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Academy name",
							defaultValue: "The Best Science Academy"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SettingsCard, {
						icon: Search,
						title: "Search & metadata",
						description: "How your academy appears in search results and social shares.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "SEO title",
							defaultValue: "World-class online tutors for international students"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "SEO description",
							defaultValue: "Premium online tuition for IGCSE, O Level, A Level, IB, AQA and Edexcel.",
							textarea: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsCard, {
						icon: Palette,
						title: "Branding",
						description: "Primary and accent colours used across the site.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-5 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorField, {
								label: "Primary color",
								defaultValue: "#2F2B8F"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorField, {
								label: "Accent color",
								defaultValue: "#006B3F"
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsCard, {
						icon: Mail,
						title: "Contact",
						description: "Where enquiries and support requests are sent.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Support email",
							defaultValue: "hello@thebestscienceacademy.com",
							type: "email"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn-primary",
							type: "submit",
							children: "Save changes"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn-ghost",
							type: "reset",
							children: "Reset"
						})]
					})
				]
			})
		]
	});
}
function SettingsCard({ icon: Icon, title, description, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card-surface p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-5 flex items-center gap-3 border-b border-border/70 pb-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary-soft text-primary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-bold text-ink",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: description
			})] })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-5",
			children
		})]
	});
}
function Field({ label, defaultValue, textarea, type = "text" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm font-semibold text-ink",
			children: label
		}), textarea ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			defaultValue,
			rows: 3,
			className: "mt-2 w-full rounded-xl border border-border bg-surface-2 px-4 py-2.5 text-sm outline-none transition-colors focus:border-primary focus:bg-surface"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type,
			defaultValue,
			className: "mt-2 h-11 w-full rounded-xl border border-border bg-surface-2 px-4 text-sm outline-none transition-colors focus:border-primary focus:bg-surface"
		})]
	});
}
function ColorField({ label, defaultValue }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm font-semibold text-ink",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-2 flex items-center gap-3 rounded-xl border border-border bg-surface-2 px-3 py-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "h-7 w-7 shrink-0 rounded-lg border border-border",
				style: { backgroundColor: defaultValue }
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				defaultValue,
				className: "h-7 w-full bg-transparent text-sm font-medium text-ink outline-none"
			})]
		})]
	});
}
//#endregion
export { SettingsAdmin as component };
